var readlineSync = require('readline-sync');
var chalk = require('chalk');

var score = 0;
var combo = 1;

var highOne ={
  name : "Pratham",
  score : -100
}
var highTwo={
  name : "Jack",
  score : -100
}
var highThree={
  name : "Cain",
  score : -100
}

//HighScores are set as such to show the working of compareHigh() and checkHigh()

var highScorers = [highOne, highTwo, highThree];

function printHighs(){
  for(z=0;z<highScorers.length;z++){
    console.log(chalk.bgWhite.yellow.bold(highScorers[z].name+'\t\t\t\t'+highScorers[z].score));
  }
}

function compareScore(score){
  var pos=0;
  var a=highOne.score;
  var b=highTwo.score;
  var c=highThree.score;
  var comp=[a,b,c];
  for (i=0;i<4;i++){
    if(pos==0){
      if(score>=comp[i]){
        pos=(i+1);
      }
    }
  }
  return pos;
}

function checkHigh(){
  var pos = compareScore(score)
  if(pos>0){ console.log(chalk.bgWhite.blue.bold.underline("Congratulations ! You qualify for "+pos+" place and your score is "+chalk.greenBright(score)));
  }else{
    console.log(chalk.bgWhite.bold.blue.underline("Your final score is ")+chalk.greenBright(score));
  }
}

var questionOne = {
  que : "Who is Naruto's rival ?" ,
  ans : 'Sasuke',
}

var questionTwo = {
  que : 'Where was Naruto born ? \n\n a.Hidden Mist\n b.Hidden Leaf\n c. Hidden Sand\n d. Hidden Cloud',
  ans : 'b'
}

var questionThree = {
  que : "What is the name of Naruto's tailed beast ?",
  ans : 'kurama'
}

var questionFour = {
  que : "Who was Naruto's first teacher ? \n\n a.Iruka Sensei\n b.Jiraya Sensei\n c.Minato Sensei\n d.Kakashi sensei",
  ans : 'a'
}

var questionFive = {
  que : "What is Naruto's favourite dish ?",
  ans : 'Ramen'
}

var questionSix = {
  que : "What is Naruto's signature move ? \n\n a.Rasengan\n b.Shadow Clone\n c.Thousand Years Of Death\n d.Rasen Shuiken",
  ans : "d" 
}

var questionSeven = {
  que : "What is the nature of Naruto's chakra ?",
  ans : "wind"
}

var questionEight = {
  que : "What did jiraya teach Naruto ?\n\n a.Shadow Clone Jutsu\n b.Fireball jutsu\n c.Rasengan\n d.Genjutsu",
  ans : "c"
}

var questionNine = {
  que : "What is Naruto's surname ?",
  ans : "uzumaki"
}

var questionTen = {
  que : "Which numbering hokage is Naruto ? ",
  ans : "eighth"
}

var questions = [ questionOne, questionTwo, questionThree, questionFour, questionFive, questionSix, questionSeven, questionEight, questionNine, questionTen ]

var queOne = {
  que : "What is naruto's hobby ? \n\n a.Swimming\n b.Travelling\n c.Gardening\n d.Dancing",
  ans : 'c'
}
var queTwo = {
  que : "What is Naruto's birthday ?\n\n a.5th June\n b.10th October\n c.23rd January\n d.28th December ",
  ans : 'b' 
}
var queThree = {
  que : "What is the color of Naruto's eyes? ",
  ans : "blue"
}
var queFour = {
  que : "What is Naruto's height ?\n\n a.183 cm\n b.166cm\n c.153cm\n d.200cm",
  ans : 'b'
}
var queFive = {
  que : "What is Naruto's blood type ? \n\n a.B\n b.A\n c.O\n d.AB",
  ans : 'a'
}
var questionsLvlTwo = [queOne, queTwo, queThree, queFour, queFive];

var levels = [questions, questionsLvlTwo];

function play( question, answer){
  var userAns= readlineSync.question(chalk.bgWhite.cyan.bold(question));
 
  if(userAns.toUpperCase() === answer.toUpperCase()){
    console.log(chalk.greenBright("Correct Answer !"));
    combo = combo+1;
      if(combo >= 5){
      score = score+(5*combo);
    }else{
      score = score +(2*combo)
    }
  }else {
    console.log(chalk.redBright('Wrong Answer :('));
    score = score -2;
    combo = 1;
    console.log(chalk.redBright('Combo has been reset'));
  }
  console.log(chalk.greenBright("Current Score : "+score));
  console.log(chalk.greenBright(("Current Combo : "+chalk.yellowBright.bold(combo ))))
  console.log(chalk.bgGray.white('------------------------'));
}

var userName = readlineSync.question("Hello there human!, how would thee want to be adressed ? ")
console.log(chalk.bgWhite.bold.black("WELCOME "+chalk.yellowBright.bold(userName.toUpperCase())+" TO HOW WELL DO YOU KNOW NARUTO ? \n\n "))
console.log(chalk.bgBlackBright.white('-------------------------------------------------------------------------------'));



console.log("Rules : \n 1.2 points for a right answer.\n 2.-2 points for a wrong answer.\n 3.Chaining combos give bonus points\n 4.Chain combos of 5 or more to get an extra boost!")
var confirm = readlineSync.keyInPause("Press any key to start !")
console.log(chalk.bgBlackBright.white('-------------------------------------------------------------------------------\n'));

for(i=0;i<questions.length;i++){

  play(questions[i].que,questions[i].ans)
}

if(readlineSync.keyInYN("Do you want toplay level 2?\nCurrent score will be carried forward\nPress Y or N")){
  for(i=0;i<questionsLvlTwo.length;i++){

    play(questionsLvlTwo[i].que,questionsLvlTwo[i].ans)
  }
}

console.log("Thank You ! for playing, check out the High Scores : ")
console.log(chalk.bgGray.white("-----------"));
printHighs();
checkHigh();
console.log(chalk.bgGray.white("-----------"));
console.log('Beat the high score ? Send me a screenshot of your results to get you name above !');


